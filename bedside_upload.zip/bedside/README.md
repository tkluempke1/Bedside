# Bedside

Bedside is a work–in‑progress platform designed to collect anonymous, verified
patient experiences for hospitals, clinics and clinicians.  The goal of the
project is to provide a trusted place for patients and care‑givers to share
structured reviews and for providers to respond in a HIPAA‑safe manner.  This
repository contains the scaffolding of a monorepo with separate apps for the
front‑end and back‑end, shared packages for UI components and schemas, and
infrastructure definitions.

## Repository layout

```text
bedside/
├── apps/
│   ├── web/             # Next.js 14 application (client and server components)
│   └── api/             # NestJS REST API service
├── packages/
│   ├── ui/              # Shared React components used by the web app
│   └── schemas/         # Zod schemas shared between the front‑end and back‑end
├── infra/               # Infrastructure as code (Terraform modules, omitted here)
├── scripts/             # Helper scripts (empty for now)
└── README.md            # This file
```

## Getting started

This is an early scaffold of the Bedside monorepo.  Running the application
requires Node.js (v20 or newer), npm (v9 or newer) and, for production use,
access to a PostgreSQL database.  The API uses Prisma as its ORM, but is
configured to fall back to SQLite in development for ease of testing.  The
front‑end is a Next.js 14 project using the App Router, TailwindCSS and
React Query.

### Install dependencies

At the repository root run:

```bash
npm install
```

This will install dependencies for all workspaces.

### Running in development

To start the API server and the web application concurrently, run:

```bash
npm run dev:api
npm run dev:web
```

The API will listen on port 3001 by default and the web application on port 3000.  For
simplicity the web application is configured to call the API using a relative
path when running locally (e.g. `/api/v1/facilities`).

### Database

The API uses Prisma and expects a `DATABASE_URL` environment variable.  In
development it falls back to an SQLite file at `./prisma/dev.db`.  To create
the database and generate Prisma client code run:

```bash
cd apps/api
npx prisma generate
npx prisma migrate dev --name init
```

## Disclaimer

This repository contains only a minimal scaffold intended as a starting point
for development.  It does **not** implement the full Bedside specification.
Many of the entities and endpoints described in the specification are stubbed
or omitted.  The code is provided for illustration and should be extended
to meet the functional, security and compliance requirements outlined in the
project brief.