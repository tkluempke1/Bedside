import { z } from 'zod';

// Enumerations for reuse
export const targetTypeEnum = z.enum(['facility', 'clinician']);
export const encounterSettingEnum = z.enum(['inpatient', 'outpatient', 'ed']);

// Review dimensions keys and schema
export const reviewDimensionsSchema = z.object({
  communication: z.number().int().min(1).max(5),
  responsiveness: z.number().int().min(1).max(5),
  cleanliness: z.number().int().min(1).max(5),
  discharge_info: z.number().int().min(1).max(5),
  wait_time: z.number().int().min(1).max(5),
  empathy: z.number().int().min(1).max(5),
});

/**
 * Zod schema defining the shape of a review submission.  This schema is
 * shared between the front‑end and back‑end to ensure that client‑side
 * validation matches server expectations.  Additional validation such as
 * profanity/PII filtering and rate limiting should be implemented on the server.
 */
export const reviewSchema = z.object({
  target_type: targetTypeEnum,
  target_id: z.string().min(1, { message: 'target_id is required' }),
  encounter_setting: encounterSettingEnum,
  // store date string representing the first day of the encounter month (YYYY-MM)
  encounter_month: z
    .string()
    .regex(/^[0-9]{4}-[0-9]{2}$/, { message: 'encounter_month must be YYYY-MM' }),
  overall: z.number().int().min(1).max(5),
  would_recommend: z.boolean(),
  dimensions: reviewDimensionsSchema,
  text: z.string().optional().max(5000),
  tags: z.array(z.string()).optional(),
  attestation: z.literal(true),
});

export type ReviewInput = z.infer<typeof reviewSchema>;